# mypackage

This library was created as project of creating packages for python

## building this package locally
'pyhton setup sdist'

## you have to install this package from  github
'pip install --upgrade git https://github.com/mhlangaV/mypackage'


## the recursion.py file consists of the following functions
the sum_array function which takes an array and return  sum of all items
the function is calling the build in python function sum_array

## fibonacci function which takes one parameter and return fibonocci sequence

## factorial function which takes one parameter and return the factorial of the parameter

## reverse function which takes a list or word then return it in reverse



#  sorting.py file

bubble_sort the return a sorted

merge_sort which return sorted

quick_sort which return
